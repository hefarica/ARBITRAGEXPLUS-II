
# ARBITRAGEX SUPREME V3.6 - Installer/Runner
param(
  [string]$ConfigPath = ".\deploy-config.json"
)
$ErrorActionPreference = "Stop"

function Write-Log([string]$msg, [string]$level="INFO") {
  $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
  Write-Host "[$ts][$level] $msg"
}

# Basic checks
function Require-Admin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  $p = New-Object Security.Principal.WindowsPrincipal($id)
  if(-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Log "Ejecuta PowerShell como Administrador." "ERROR"
    exit 1
  }
}

function Confirm-Tool($cmd, $friendly) {
  if (Get-Command $cmd -ErrorAction SilentlyContinue) { 
    Write-Log "$friendly encontrado." 
  } else {
    Write-Log "$friendly NO encontrado. Instálalo y vuelve a ejecutar." "ERROR"
    exit 1
  }
}

function Open-Env-Files($cfg) {
  $envs = @($cfg.envFiles.backend, $cfg.envFiles.selector, $cfg.envFiles.workers, $cfg.envFiles.dashboard)
  foreach($e in $envs) {
    if(-not [string]::IsNullOrWhiteSpace($e)) {
      $p = Resolve-Path -Path $e -ErrorAction SilentlyContinue
      if(-not $p) {
        # create empty .env
        New-Item -ItemType File -Path $e -Force | Out-Null
        Add-Content -Path $e -Value "# Edita credenciales, RPCs, claves. Nunca subas este archivo a Git."
      }
      Write-Log "Abriendo $e para edición..."
      Start-Process notepad.exe $e
    }
  }
}

function Up-Compose($cfg) {
  $compose = $cfg.docker.composeFile
  if(-not (Test-Path $compose)) {
    Write-Log "docker-compose.yml no encontrado en $compose" "ERROR"
    exit 1
  }
  Push-Location (Split-Path -Parent $compose)
  try {
    Write-Log "Levantando servicios con docker compose..."
    docker compose up -d --build
  } finally {
    Pop-Location
  }
}

function Wait-HTTP($url, $timeoutSec=180) {
  $deadline = (Get-Date).AddSeconds($timeoutSec)
  while((Get-Date) -lt $deadline) {
    try {
      $r = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 5
      if($r.StatusCode -ge 200 -and $r.StatusCode -lt 400) {
        return $true
      }
    } catch {}
    Start-Sleep -Seconds 3
  }
  return $false
}

Require-Admin
Confirm-Tool docker "Docker"
Confirm-Tool git "Git"
Confirm-Tool node "Node.js"

if(-not (Test-Path $ConfigPath)) {
  Write-Log "deploy-config.json no existe: $ConfigPath" "ERROR"
  exit 1
}
$cfg = Get-Content $ConfigPath -Raw | ConvertFrom-Json

# Paso 1: abrir .env para que el usuario agregue credenciales
Write-Log "Abriendo editores para .env..."
Open-Env-Files -cfg $cfg
Write-Log "Continúa cuando hayas guardado los .env necesarios."

# Paso 2: docker compose up (build + run)
Up-Compose -cfg $cfg

# Paso 3: esperar APIs y abrir dashboard
$selectorPort = $cfg.ports.selector
$dashPort = $cfg.ports.dashboard
$ok = Wait-HTTP -url ("http://localhost:{0}" -f $dashPort)
if($ok) {
  Write-Log "Dashboard operativo en http://localhost:$dashPort"
  Start-Process ("http://localhost:{0}" -f $dashPort) | Out-Null
} else {
  Write-Log "No se pudo verificar el dashboard en el tiempo esperado." "WARN"
}

Write-Log "Listo. Revisa Prometheus (http://localhost:{0}) y Grafana (http://localhost:{1}) si están configurados." -f $cfg.ports.prometheus, $cfg.ports.grafana
