# ARBITRAGEX SUPREME V3.6 — Unified Package

This repo bundles backend, workers, dashboard and installer scripts.
