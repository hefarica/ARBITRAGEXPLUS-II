# README — Instalador

1. Edita `deploy-config.json` y pega **tus** URLs reales.
2. (Opcional) Edita `.env.example` con los valores por defecto de tu entorno.
3. Ejecuta `INSTALL-ARBITRAGEX.bat` **como Administrador**.
4. El instalador abrirá `Notepad` con `.env` para que completes credenciales faltantes (wallet).
5. Si faltan URLs de repos, verás un aviso. Complétalas y vuelve a ejecutar.