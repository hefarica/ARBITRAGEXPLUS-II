# ========================================================================================================
# ARBITRAGEX SUPREME V3.6 — Installer (Hardened, No Hardcodes)
# - No inventa datos ni URLs: TODO sale de deploy-config.json o interacción del usuario.
# - Sin New-Object para tareas comunes; uso de .NET mínimo y seguro para cuadro de diálogo.
# - Idempotente: puede re-ejecutarse sin romper nada.
# ========================================================================================================
[CmdletBinding()]
param(
  [string]$BaseDir = "$env:USERPROFILE\ARBITRAGEX-SUPREME-V3.6"
)

$ErrorActionPreference = 'Stop'

function Write-Log {
  param([string]$Message, [ValidateSet('INFO','WARN','ERROR')][string]$Level='INFO')
  $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
  $color = if ($Level -eq 'INFO') {'Green'} elseif ($Level -eq 'WARN') {'Yellow'} else {'Red'}
  Write-Host "[$ts][$Level] $Message" -ForegroundColor $color
}

function Require-Admin {
  $isAdmin = (whoami /groups /fo csv | ConvertFrom-Csv | Where-Object { $_.'Group Name' -match 'Administrators' }).Count -gt 0
  if (-not $isAdmin) {
    Write-Log "Ejecuta este instalador como **Administrador**." 'ERROR'
    exit 1
  }
}

function Ensure-Dir([string]$path) {
  if (-not (Test-Path -Path $path)) { New-Item -ItemType Directory -Path $path | Out-Null }
}

function Read-Json([string]$file) {
  if (-not (Test-Path $file)) { throw "No existe $file" }
  Get-Content $file -Raw | ConvertFrom-Json
}

function Test-Cmd($cmd) {
  $null = & cmd /c "where $cmd" 2>$null
  return $LASTEXITCODE -eq 0
}

function Prompt-String([string]$title, [string]$text) {
  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
  # MessageBox para UX mínima sin New-Object
  [System.Windows.Forms.MessageBox]::Show($text, $title, [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
}

Require-Admin
Ensure-Dir -path $BaseDir
Set-Location -Path $BaseDir

# 1) Cargar configuración
$configPath = Join-Path $PSScriptRoot 'deploy-config.json'
if (-not (Test-Path $configPath)) {
  Write-Log "deploy-config.json no encontrado. Creando uno base..." 'WARN'
  $defaultJson = @"
{}
"@
  $defaultJson | Set-Content -Path $configPath -Encoding UTF8
  throw "Aborta: completa deploy-config.json y vuelve a ejecutar."
}
$config = Read-Json $configPath

# 2) Validaciones de binarios (no instalamos por ti, te guiamos)
foreach ($bin in @('git','docker','docker-compose','node','npm')) {
  if (-not (Test-Cmd $bin)) {
    Write-Log "No se encontró '$bin'. Instálalo y vuelve a ejecutar." 'WARN'
  } else {
    Write-Log "OK: $bin" 'INFO'
  }
}

# 3) Estructura base
$dirs = @('CONTABO-BACKEND','CLOUDFLARE-SUPREME','LOVABLE-DASHBOARD','logs','tmp')
foreach ($d in $dirs) { Ensure-Dir -path (Join-Path $BaseDir $d) }

# 4) Clonado de repos (si configuraste URLs)
if ($config.repos) {
  foreach ($r in $config.repos) {
    $name = $r.name
    $url  = $r.url
    $branch = if ($r.branch) { $r.branch } else { 'main' }
    if ([string]::IsNullOrWhiteSpace($url)) {
      Write-Log "Repo '$name' sin URL. Saltando (edita deploy-config.json)." 'WARN'
      continue
    }
    $target = Join-Path $BaseDir $name
    if (-not (Test-Path (Join-Path $target '.git'))) {
      Write-Log "Clonando $name desde $url ..." 'INFO'
      git clone --branch $branch --depth 1 $url $target
    } else {
      Write-Log "Actualizando $name ..." 'INFO'
      Push-Location $target
      git fetch --all --prune
      git reset --hard "origin/$branch"
      Pop-Location
    }
  }
}

# 5) Preparar .env
$envFile = if ($config.envFile) { $config.envFile } else { '.env' }
$envPath = Join-Path $BaseDir $envFile
if (-not (Test-Path $envPath)) {
  if (Test-Path (Join-Path $BaseDir '.env.example')) {
    Copy-Item (Join-Path $BaseDir '.env.example') $envPath -Force
  } else {
    "# .env raíz generado — completa solo lo necesario" | Set-Content -Path $envPath -Encoding UTF8
  }
  Write-Log "Se creó $envFile. Debes completarlo con tus credenciales (wallet, endpoints, etc.)." 'INFO'
}

# 6) Abrir UI mínima para recordar completar .env y pedir URLs si faltan
$missingRepos = @()
foreach ($r in $config.repos) { if (-not $r.url -or [string]::IsNullOrWhiteSpace($r.url)) { $missingRepos += $r.name } }
if ($missingRepos.Count -gt 0) {
  $msg = "Faltan URLs de los siguientes repos: `n - " + ($missingRepos -join "`n - ") + "`n`nAbre deploy-config.json, agrega tus URLs y vuelve a ejecutar."
  Prompt-String -title "Config Incompleta" -text $msg
}
# Abrir .env en Notepad para UX simple
Start-Process notepad.exe $envPath

# 7) Sugerir próximos pasos (no ejecutamos docker-compose sin repos válidos)
Write-Log "Si ya clonaste tus repos, ejecuta sus guías de despliegue o docker-compose conforme a tu código real." 'INFO'
if ($config.openBrowserOnFinish -eq $true) {
  Write-Log "Abrir documentación local (README)..." 'INFO'
  if (Test-Path (Join-Path $PSScriptRoot 'README-INSTALLER.md')) {
    Start-Process (Join-Path $PSScriptRoot 'README-INSTALLER.md')
  }
}

Write-Log "Instalación base finalizada. Vuelve a ejecutar tras completar deploy-config.json y .env." 'INFO'