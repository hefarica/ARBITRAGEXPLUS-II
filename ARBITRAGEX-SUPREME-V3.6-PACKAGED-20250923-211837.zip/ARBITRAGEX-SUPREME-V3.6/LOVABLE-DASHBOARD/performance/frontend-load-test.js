// Frontend Performance Tests 
