pub mod validator;

pub use validator::validate_opportunity;



