# ⚠️ LECTURA OBLIGATORIA

Este paquete integra los 3 repos (backend, workers, dashboard) bajo **ARBITRAGEX SUPREME V3.6**.
Antes de operar con fondos:
1) Revisa `.env` en **cada** subproyecto (no hay llaves incluidas).
2) Asegúrate de que Docker Desktop esté en ejecución.
3) Ejecuta `RUN-ARBITRAGEX.bat` (doble clic) como **Administrador**.
4) El script abrirá `http://localhost:3100` una vez que todo esté arriba.
5) No compartas llaves privadas ni seeds. Usa variables de entorno seguras o HSM.

Soporta auditoría: logs, Prometheus/Grafana, y P&L por ejecuciones.